#!/bin/bash

indent -i3 -bli0 *.[ch]
